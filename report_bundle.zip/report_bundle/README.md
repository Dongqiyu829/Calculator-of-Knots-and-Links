# Quantum Groups, Yang-Baxter Equations, and Braid-Based Knot Invariants

This repository is a UROP project on braid-based knot invariant computation from quantum-group data. The codebase contains reusable algebra and braid modules, a main GUI/workbench for current branches, and a fully parallel benchmark_lab tree for report-ready profile and audit experiments.

## Main components

- `src/`: algebra, braid, R-matrix, invariant, GUI, workbench, and benchmark_lab code.
- `examples/`: runnable entry scripts for demos, GUI tools, and the isolated benchmark_lab CLIs.
- `data/benchmark_lab/`: CSV and JSON benchmark templates used by the isolated experiment layer.
- `docs/`: project notes, mathematical status notes, benchmark_lab notes, and report-facing reproducibility material.
- `artifacts/benchmark_lab/`: exported profile and audit results from benchmark_lab runs.

## Current branches

- `sl2_fundamental`: the current Jones-compatible branch.
- `sl2_3d_9x9`: the current colored Jones candidate branch built from the 3-dimensional `sl2` representation.
- `sl3_fundamental`: the current `sl3` fundamental branch.

## Current benchmark status

The isolated benchmark_lab keeps the comparison order fixed as:

`(sl2_fundamental, sl2_3d_9x9, sl3_fundamental)`

with `same -> 0` and `different -> 1`.

The current main benchmark result is `P03 = 10_22 vs 10_35`. In the stored benchmark_lab runs, the observed profile is `(0,1,1)` for `q=2`, `q=3`, and `q=5`, and the symbolic `q=q` audit is consistent with the same separation pattern. This is the cleanest current example where the two 9x9 lines separate a pair that the `sl2_fundamental` branch does not separate.

`P01 = 5_1 vs 5_1_stabilized` and `P04 = 5_1 vs 10_132` should be read as audit cases, not as final conclusions. `P01` is a stabilization control case. `P04` is a literature/convention reconciliation case. `P05` is a placeholder pair that is intentionally skipped until the braid source is audited.

## How to run benchmark_lab

Profile runs:

```bash
python examples/benchmark_lab/run_benchmark_profiles.py --input data/benchmark_lab/benchmark_pairs_template.csv --q 2
python examples/benchmark_lab/run_benchmark_profiles.py --input data/benchmark_lab/benchmark_pairs_template.csv --q 3
python examples/benchmark_lab/run_benchmark_profiles.py --input data/benchmark_lab/benchmark_pairs_template.csv --q 5
python examples/benchmark_lab/run_benchmark_profiles.py --input data/benchmark_lab/benchmark_pairs_template.csv --q q
```

Audit runs:

```bash
python examples/benchmark_lab/run_benchmark_audit.py --input data/benchmark_lab/benchmark_pairs_template.csv --pair P01 --q 2
python examples/benchmark_lab/run_benchmark_audit.py --input data/benchmark_lab/benchmark_pairs_template.csv --pair P04 --q 2
python examples/benchmark_lab/run_benchmark_audit.py --input data/benchmark_lab/benchmark_pairs_template.csv --pair P03 --q q
```

Outputs are written under `artifacts/benchmark_lab/`.

## Repository status

This repository should be read together with the UROP report. Some benchmark pairs already show stable behavior across multiple `q` choices, while some pairs still require audit before any stronger mathematical claim should be made. The benchmark_lab tree is the recommended path for reproducible report experiments because it does not modify the existing main GUI, workbench, or legacy code paths.