# Audit P03 (q=3)

Status: completed

Notes: Main positive separation-profile benchmark.

## Braid A
- label: 10_22
- source: Candidate braid representative for 10_22
- num_strands: 4
- generators: [1, 1, 1, 1, 2, -1, -3, 2, -3, -3, -3]
- writhe: 1
- is_placeholder: False

## Braid B
- label: 10_35
- source: Candidate braid representative for 10_35
- num_strands: 6
- generators: [-1, 2, -1, 2, 3, -2, -4, 3, 5, -4, 5]
- writhe: 1
- is_placeholder: False

## Branch audits

### Jones / sl2 fundamental
- relation: same
- output A: 2859253489/531441
- output B: 2859253489/531441
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 0.
- symbolic difference: n/a
- numeric witness: 0

### sl2 的3维表示下的9x9矩阵
- relation: different
- output A: 33678020773448983646676864721/16677181699666569
- output B: 33217935818768788990011264721/16677181699666569
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 70124211961620889600000/2541865828329.
- symbolic difference: n/a
- numeric witness: 70124211961620889600000/2541865828329

### sl3 fundamental
- relation: different
- output A: 208690626755611/387420489
- output B: 18346685834976499/3486784401
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is -16468470194176000/3486784401.
- symbolic difference: n/a
- numeric witness: -16468470194176000/3486784401