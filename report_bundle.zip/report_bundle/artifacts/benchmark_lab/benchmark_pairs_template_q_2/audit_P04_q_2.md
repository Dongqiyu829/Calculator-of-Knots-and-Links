# Audit P04 (q=2)

Status: completed

Notes: Primary audit mismatch case for the benchmark lab.

## Braid A
- label: 5_1
- source: Closure of sigma_1^5 on two strands
- num_strands: 2
- generators: [1, 1, 1, 1, 1]
- writhe: 5
- is_placeholder: False

## Braid B
- label: 10_132
- source: Candidate braid representative for 10_132
- num_strands: 4
- generators: [1, 1, 1, -2, -1, -1, -2, -3, 2, -3, -3]
- writhe: -3
- is_placeholder: False

## Branch audits

### Jones / sl2 fundamental
- relation: different
- output A: 1075/16384
- output B: -13040
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 213648435/16384.
- symbolic difference: n/a
- numeric witness: 213648435/16384

### sl2 的3维表示下的9x9矩阵
- relation: different
- output A: 1089719869/268435456
- output B: 12565016366179/256
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is -13175374600092791235/268435456.
- symbolic difference: n/a
- numeric witness: -13175374600092791235/268435456

### sl3 fundamental
- relation: different
- output A: 91371/4194304
- output B: -5482176
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 22993912816875/4194304.
- symbolic difference: n/a
- numeric witness: 22993912816875/4194304