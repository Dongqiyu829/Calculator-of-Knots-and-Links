# Audit P01 (q=2)

Status: completed

Notes: Primary audit control pair.

## Braid A
- label: 5_1
- source: Closure of sigma_1^5 on two strands
- num_strands: 2
- generators: [1, 1, 1, 1, 1]
- writhe: 5
- is_placeholder: False

## Braid B
- label: 5_1_stabilized
- source: Positive stabilization candidate of 5_1
- num_strands: 3
- generators: [1, 1, 1, 1, 1, -2]
- writhe: 4
- is_placeholder: False

## Branch audits

### Jones / sl2 fundamental
- relation: same
- output A: 1075/16384
- output B: 1075/16384
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 0.
- symbolic difference: n/a
- numeric witness: 0

### sl2 的3维表示下的9x9矩阵
- relation: different
- output A: 1089719869/268435456
- output B: 1089719869/1073741824
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 3269159607/1073741824.
- symbolic difference: n/a
- numeric witness: 3269159607/1073741824

### sl3 fundamental
- relation: same
- output A: 91371/4194304
- output B: 91371/4194304
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 0.
- symbolic difference: n/a
- numeric witness: 0