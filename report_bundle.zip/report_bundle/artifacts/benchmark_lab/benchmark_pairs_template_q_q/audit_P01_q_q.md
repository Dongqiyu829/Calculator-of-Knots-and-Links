# Audit P01 (q=q)

Status: completed

Notes: Primary audit control pair.

## Braid A
- label: 5_1
- source: Closure of sigma_1^5 on two strands
- num_strands: 2
- generators: [1, 1, 1, 1, 1]
- writhe: 5
- is_placeholder: False

## Braid B
- label: 5_1_stabilized
- source: Positive stabilization candidate of 5_1
- num_strands: 3
- generators: [1, 1, 1, 1, 1, -2]
- writhe: 4
- is_placeholder: False

## Branch audits

### Jones / sl2 fundamental
- relation: same
- output A: (q**10 + q**6 - q**4 + q**2 - 1)/q**14
- output B: (q**10 + q**6 - q**4 + q**2 - 1)/q**14
- decision: Symbolic mode compares sympy.simplify(output_A - output_B) against 0. The simplified difference is 0.
- symbolic difference: 0
- numeric witness: n/a

### sl2 的3维表示下的9x9矩阵
- relation: different
- output A: (q**30 + q**24 - q**20 + q**18 - q**14 + q**12 - 2*q**8 + q**6 - q**2 + 1)/q**28
- output B: (q**30 + q**24 - q**20 + q**18 - q**14 + q**12 - 2*q**8 + q**6 - q**2 + 1)/q**30
- decision: Symbolic mode compares sympy.simplify(output_A - output_B) against 0. The simplified difference is (q**32 - q**30 + q**26 - q**24 - q**22 + 2*q**20 - q**18 - q**16 + 2*q**14 - q**12 - 2*q**10 + 3*q**8 - q**6 - q**4 + 2*q**2 - 1)/q**30.
- symbolic difference: (q**32 - q**30 + q**26 - q**24 - q**22 + 2*q**20 - q**18 - q**16 + 2*q**14 - q**12 - 2*q**10 + 3*q**8 - q**6 - q**4 + 2*q**2 - 1)/q**30
- numeric witness: n/a

### sl3 fundamental
- relation: same
- output A: (q**16 + q**14 + 2*q**12 + q**10 + q**8 - q**4 - q**2 - 1)/q**22
- output B: (q**16 + q**14 + 2*q**12 + q**10 + q**8 - q**4 - q**2 - 1)/q**22
- decision: Symbolic mode compares sympy.simplify(output_A - output_B) against 0. The simplified difference is 0.
- symbolic difference: 0
- numeric witness: n/a