# Audit P03 (q=q)

Status: completed

Notes: Main positive separation-profile benchmark.

## Braid A
- label: 10_22
- source: Candidate braid representative for 10_22
- num_strands: 4
- generators: [1, 1, 1, 1, 2, -1, -3, 2, -3, -3, -3]
- writhe: 1
- is_placeholder: False

## Braid B
- label: 10_35
- source: Candidate braid representative for 10_35
- num_strands: 6
- generators: [-1, 2, -1, 2, 3, -2, -4, 3, 5, -4, 5]
- writhe: 1
- is_placeholder: False

## Branch audits

### Jones / sl2 fundamental
- relation: same
- output A: (q**22 - q**20 + 2*q**18 - 2*q**16 + 2*q**14 - q**10 + q**8 - 2*q**6 + 2*q**4 - q**2 + 1)/(q**12*(q**2 + 1))
- output B: (q**22 - q**20 + 2*q**18 - 2*q**16 + 2*q**14 - q**10 + q**8 - 2*q**6 + 2*q**4 - q**2 + 1)/(q**12*(q**2 + 1))
- decision: Symbolic mode compares sympy.simplify(output_A - output_B) against 0. The simplified difference is 0.
- symbolic difference: 0
- numeric witness: n/a

### sl2 的3维表示下的9x9矩阵
- relation: different
- output A: q**26 - 2*q**24 + q**22 + 4*q**20 - 8*q**18 + 3*q**16 + 11*q**14 - 20*q**12 + 6*q**10 + 24*q**8 - 37*q**6 + 8*q**4 + 39*q**2 - 48 + 5/q**2 + 45/q**4 - 45/q**6 - 3/q**8 + 43/q**10 - 32/q**12 - 10/q**14 + 33/q**16 - 17/q**18 - 11/q**20 + 18/q**22 - 5/q**24 - 7/q**26 + 6/q**28 - 2/q**32 + q**(-34)
- output B: q**26 - 2*q**24 + 5*q**20 - 7*q**18 + q**16 + 12*q**14 - 19*q**12 + 5*q**10 + 24*q**8 - 36*q**6 + 7*q**4 + 39*q**2 - 47 + 3/q**2 + 46/q**4 - 45/q**6 - 4/q**8 + 44/q**10 - 32/q**12 - 11/q**14 + 34/q**16 - 16/q**18 - 13/q**20 + 19/q**22 - 4/q**24 - 8/q**26 + 6/q**28 - 2/q**32 + q**(-34)
- decision: Symbolic mode compares sympy.simplify(output_A - output_B) against 0. The simplified difference is (q**48 - q**46 - q**44 + 2*q**42 - q**40 - q**38 + q**36 - q**32 + q**30 - q**26 + 2*q**24 - q**22 + q**18 - q**16 + q**12 - q**10 - q**8 + 2*q**6 - q**4 - q**2 + 1)/q**26.
- symbolic difference: (q**48 - q**46 - q**44 + 2*q**42 - q**40 - q**38 + q**36 - q**32 + q**30 - q**26 + 2*q**24 - q**22 + q**18 - q**16 + q**12 - q**10 - q**8 + 2*q**6 - q**4 - q**2 + 1)/q**26
- numeric witness: n/a

### sl3 fundamental
- relation: different
- output A: (q**30 + q**26 + q**24 - q**22 + 2*q**20 - q**18 - q**14 - 2*q**12 + q**10 - q**8 + q**6 + q**4 + 1)/q**18
- output B: (q**34 + q**32 - q**30 + q**28 - 2*q**24 + 2*q**22 + q**18 - q**14 + q**12 - 2*q**10 + q**6 - q**4 + q**2 + 1)/q**20
- decision: Symbolic mode compares sympy.simplify(output_A - output_B) against 0. The simplified difference is (-q**34 + q**30 + q**26 + q**24 - q**20 - q**18 - q**16 - q**14 + q**10 + q**8 + q**4 - 1)/q**20.
- symbolic difference: (-q**34 + q**30 + q**26 + q**24 - q**20 - q**18 - q**16 - q**14 + q**10 + q**8 + q**4 - 1)/q**20
- numeric witness: n/a