# Audit P03 (q=5)

Status: completed

Notes: Main positive separation-profile benchmark.

## Braid A
- label: 10_22
- source: Candidate braid representative for 10_22
- num_strands: 4
- generators: [1, 1, 1, 1, 2, -1, -3, 2, -3, -3, -3]
- writhe: 1
- is_placeholder: False

## Braid B
- label: 10_35
- source: Candidate braid representative for 10_35
- num_strands: 6
- generators: [-1, 2, -1, 2, 3, -2, -4, 3, 5, -4, 5]
- writhe: 1
- is_placeholder: False

## Branch audits

### Jones / sl2 fundamental
- relation: same
- output A: 88313645221201/244140625
- output B: 88313645221201/244140625
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 0.
- symbolic difference: n/a
- numeric witness: 0

### sl2 的3维表示下的9x9矩阵
- relation: different
- output A: 799565161497079128323307139043058542281201/582076609134674072265625
- output B: 798234940367040866514850718053208942281201/582076609134674072265625
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is 3405366092897950229648437734014976/1490116119384765625.
- symbolic difference: n/a
- numeric witness: 3405366092897950229648437734014976/1490116119384765625

### sl3 fundamental
- relation: different
- output A: 932870098107431266251/3814697265625
- output B: 604465489391321025405651/95367431640625
- decision: Numeric mode simplifies both outputs and then performs strict equality on the resulting SymPy expressions. The simplified numeric witness output_A - output_B is -581143736938635243749376/95367431640625.
- symbolic difference: n/a
- numeric witness: -581143736938635243749376/95367431640625